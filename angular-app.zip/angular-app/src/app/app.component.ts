import { Component, OnInit } from '@angular/core';
import {Http} from "@angular/http";
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app works!';
  user : any;
  followers :any;
  
  userUrl =  'https://api.github.com/users/';
  followersUrl = 'https://api.github.com/users/michalbe/followers';
  userName:string;
  errorUser : string;
  errorFollower :string;

    constructor(protected http : Http){
         this.userName = '';
    }
    

    ngOnInit() { 
       
    }

    // get user and his/her followers
    getUserData(){
        //reset values
        this.user = null;
        this.followers = null;
        this.errorFollower = null;
        this.errorUser = null;

       this.userUrl =  'https://api.github.com/users/'+this.userName;
       this.followersUrl = 'https://api.github.com/users/'+this.userName+'/followers';
      //get user
       this.http.get(this.userUrl,{
        }).subscribe((res) => {            

         // console.log(res.json())
          this.user = res.json();
    
        }, (res) => {
            if (res.status == 404) 
            this.errorUser = "No User Found."; 
        });
      
      //get user follers
       this.http.get(this.followersUrl,{
        }).subscribe((res) => {            

        //  console.log(res.json())
          this.followers = res.json();
    
        }, (res) => {
            if (res.status == 404)
            this.errorFollower = "No Follower Found."; 
        });
    }

}
